# Project Title
Simple Calculator by python

# Getting started

<ul> 
<li> This Program run on both Windows and Linux operating system by using pycharm, anaconda 3 or all other python editor with the python version 3.x  </li>
<li> This software is developed by python 3.x </li>
<li> Used tkinter module for the Graphical User Interface </li>
<li> It performs  Addition, Subtraction, Multiplication and Division only for two numbers </li>
<li> It is more secure which means you may not enter other anything except the numerical values </li>
<li> It is more relevant and easy to use for an user </li>
</ul>

# Prerequisites
<ul>
<li>You need to install python version 3.x. you may download Python version from their official website: ../ https://www.python.org/downloads/ <br/>
or you may download a complete package by downloading anaconda: ../ https://www.anaconda.com/download/ <br/>
</li>
<li> One editor can be a good one. (i.e., pycharm, anaconda3 etc or any other that you can choice). Download pycharm:  ../ https://www.jetbrains.com/pycharm/download/#section=windows </li>
</ul>

For Linux

<ul> 
<li> To install both python and any text editor like pycharm you should do some execution of command line on the terminal.  </li>

</ul>

# Built in
<ul> <li> python 3.x  <br/></li> <li> tkinter python <br/> </li> </ul>

# Contribution
Only Belongs to the <b>Author </b>

# Author
Pranta Sarker <br/>
Department of Computer Science and Engineering <br/>
North East University Bangladesh <br/>
Sylhet, Bangladesh <br/>

# Acknowledgement
<ul> <li> Stackoverflow  <br/> </li> <li> Related blogs <br/> </li> <li> etc </li> </ul>

